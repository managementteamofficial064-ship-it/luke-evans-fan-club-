FAN CLUB & MEMBERSHIP WEBSITE — CUSTOMISED STARTER

Included: index.html with mobile-friendly layout, Regular/VIP/Golden membership application, event enquiry form, FAQ, and professional navy/gold styling.

BEFORE PUBLISHING:
1. Edit index.html and replace:
   const ADMIN_EMAIL = "replace-with-your-email@example.com";
   with the email address where you want to receive enquiries.
2. Add the real celebrity/fan-club name only if appropriate and authorised. This template intentionally uses generic wording.
3. Set real membership prices, currency, payment process, eligibility, benefits, renewal/refund terms, and event details. Prices and perks are not invented.
4. The forms open a visitor's email app (mailto). They do not store form data online, process payments, issue cards, or confirm tickets. The visitor must press Send.
5. For reliable collection and paid membership, connect a form service/database and a trusted payment provider; do not collect card numbers in these forms.

FREE HOSTING WITH GITHUB PAGES:
1. Create/sign in at https://github.com/
2. Create a public repository named fan-club-membership.
3. Upload index.html to the repository root.
4. Go to Settings > Pages.
5. Under Build and deployment, select Deploy from a branch; choose main and /(root), then Save.
6. Wait for publication. The URL will look like https://YOUR-USERNAME.github.io/fan-club-membership/
7. Test on mobile and desktop.

The website is a generic independent fan-club template and does not imply official endorsement by a celebrity or public figure. Use names, photos, logos, and claims only when you have the rights/permission.
